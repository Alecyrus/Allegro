from .app import Allegro
from .consumer import BaseConsumer

__version__ = '1.0.7'

__all__ = ['Allegro', 'BaseConsumer']
