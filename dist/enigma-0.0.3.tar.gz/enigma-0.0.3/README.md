# Enigma
Enima is a python backend integration framework, which provides a simple way to make the task of building any kind of RESTFul system easy and efficient. The RESTFul service is based on [PEcAN](https://github.com/PecanProject/pecan/), and [RabbitMQ](http://www.rabbitmq.com/) provides a message communication service. 
