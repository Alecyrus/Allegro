from .app import Allegro
from .consumer import BaseConsumer

__version__ = '1.0.5'

__all__ = ['Allegro', 'BaseConsumer']
